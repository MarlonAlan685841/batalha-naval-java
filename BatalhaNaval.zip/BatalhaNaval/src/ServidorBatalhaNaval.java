import java.io.*;
import java.net.*;

public class ServidorBatalhaNaval {
    // Porta do servidor
    private static final int PORTA = 4444;
    // Tamanho do tabuleiro (5x5)
    private static final int TAMANHO = 5;
    // Quantidade de navios que cada jogador pode posicionar
    private static final int NAVIOS = 3;

    // Tabuleiros dos jogadores
    private static char[][] tabuleiro1 = new char[TAMANHO][TAMANHO];
    private static char[][] tabuleiro2 = new char[TAMANHO][TAMANHO];

    // Sockets para os dois jogadores
    private static Socket jogador1;
    private static Socket jogador2;

    // Preenche o tabuleiro com água ('-')
    private static void inicializarTabuleiro(char[][] tabuleiro) {
        for (int i = 0; i < TAMANHO; i++) {
            for (int j = 0; j < TAMANHO; j++) {
                tabuleiro[i][j] = '-';
            }
        }
    }

    // Mostra o tabuleiro na tela (pode esconder os navios se for o tabuleiro do inimigo)
    private static String exibirTabuleiro(char[][] tabuleiro, boolean ocultarNavios) {
        StringBuilder sb = new StringBuilder();
        sb.append("Tabuleiro:\n");
        sb.append("  ");
        for (int j = 0; j < TAMANHO; j++) {
            sb.append(j).append(" ");
        }
        sb.append("\n");
        for (int i = 0; i < TAMANHO; i++) {
            sb.append(i).append(" ");
            for (int j = 0; j < TAMANHO; j++) {
                char c = tabuleiro[i][j];
                if (ocultarNavios && c == 'N') {
                    c = '-'; // Esconde os navios para o oponente
                }
                sb.append(c).append(" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    // Verifica se a coordenada está dentro do tabuleiro
    private static boolean isPosicaoValida(int linha, int coluna) {
        return linha >= 0 && linha < TAMANHO && coluna >= 0 && coluna < TAMANHO;
    }

    // Pede para o jogador posicionar os navios
    private static void posicionarNavios(BufferedReader in, PrintStream out, char[][] tabuleiro) throws IOException {
        int naviosColocados = 0;
        while (naviosColocados < NAVIOS) {
            out.println(exibirTabuleiro(tabuleiro, false)); // Mostra tabuleiro atual
            out.println("Posicione o navio " + (naviosColocados + 1) + " (formato: linha coluna):");
            try {
                String[] partes = in.readLine().split(" ");
                if (partes.length != 2) {
                    out.println("Formato inválido. Use: linha coluna");
                    continue;
                }
                int linha = Integer.parseInt(partes[0]);
                int coluna = Integer.parseInt(partes[1]);
                if (!isPosicaoValida(linha, coluna)) {
                    out.println("Posição fora do tabuleiro. Tente novamente.");
                    continue;
                }
                if (tabuleiro[linha][coluna] == '-') {
                    tabuleiro[linha][coluna] = 'N'; // Marca navio
                    naviosColocados++;
                    out.println("Navio posicionado com sucesso!");
                } else {
                    out.println("Posição já ocupada. Tente novamente.");
                }
            } catch (NumberFormatException e) {
                out.println("Entrada inválida. Use números para linha e coluna.");
            }
        }
    }

    // Trata o ataque feito por um jogador
    private static boolean processarAtaque(int linha, int coluna, char[][] tabuleiro) {
        if (tabuleiro[linha][coluna] == 'N') {
            tabuleiro[linha][coluna] = 'X'; // Acertou um navio
            return true;
        } else if (tabuleiro[linha][coluna] == '-') {
            tabuleiro[linha][coluna] = 'O'; // Errou, só água
        }
        return false;
    }

    // Verifica se o jogador perdeu (ou seja, todos os navios foram destruídos)
    private static boolean venceu(char[][] tabuleiro) {
        for (int i = 0; i < TAMANHO; i++) {
            for (int j = 0; j < TAMANHO; j++) {
                if (tabuleiro[i][j] == 'N') {
                    return false; // Ainda tem navio vivo
                }
            }
        }
        return true;
    }

    public static void main(String[] args) {
        ServerSocket servidor = null;
        try {
            servidor = new ServerSocket(PORTA);
            System.out.println("Servidor esperando dois jogadores...");

            // Espera o jogador 1 conectar
            jogador1 = servidor.accept();
            System.out.println("Jogador 1 conectado.");
            BufferedReader in1 = new BufferedReader(new InputStreamReader(jogador1.getInputStream()));
            PrintStream out1 = new PrintStream(jogador1.getOutputStream());

            // Espera o jogador 2 conectar
            jogador2 = servidor.accept();
            System.out.println("Jogador 2 conectado.");
            BufferedReader in2 = new BufferedReader(new InputStreamReader(jogador2.getInputStream()));
            PrintStream out2 = new PrintStream(jogador2.getOutputStream());

            // Prepara os tabuleiros
            inicializarTabuleiro(tabuleiro1);
            inicializarTabuleiro(tabuleiro2);

            // Jogador 1 posiciona os navios
            out1.println("Bem-vindo à Batalha Naval! Posicione seus navios.");
            posicionarNavios(in1, out1, tabuleiro1);

            // Jogador 2 posiciona os navios
            out2.println("Bem-vindo à Batalha Naval! Posicione seus navios.");
            posicionarNavios(in2, out2, tabuleiro2);

            boolean turnoJogador1 = true; // Começa com jogador 1

            while (true) {
                // Alterna os turnos
                PrintStream out = turnoJogador1 ? out1 : out2;
                BufferedReader in = turnoJogador1 ? in1 : in2;
                PrintStream outOponente = turnoJogador1 ? out2 : out1;
                char[][] tabuleiroOponente = turnoJogador1 ? tabuleiro2 : tabuleiro1;

                // Mostra tabuleiro do inimigo (sem mostrar os navios)
                out.println(exibirTabuleiro(tabuleiroOponente, true));
                out.println("Sua vez de atacar (formato: linha coluna):");
                try {
                    String[] partes = in.readLine().split(" ");
                    if (partes.length != 2) {
                        out.println("Formato inválido. Use: linha coluna");
                        continue;
                    }
                    int linha = Integer.parseInt(partes[0]);
                    int coluna = Integer.parseInt(partes[1]);
                    if (!isPosicaoValida(linha, coluna)) {
                        out.println("Posição fora do tabuleiro. Tente novamente.");
                        continue;
                    }
                    if (tabuleiroOponente[linha][coluna] == 'X' || tabuleiroOponente[linha][coluna] == 'O') {
                        out.println("Posição já atacada. Tente novamente.");
                        continue;
                    }
                    boolean acertou = processarAtaque(linha, coluna, tabuleiroOponente);
                    out.println(acertou ? "Você acertou um navio!" : "Você errou.");
                    outOponente.println("O oponente atacou a posição (" + linha + "," + coluna + "): " +
                            (acertou ? "Acertou um navio!" : "Errou."));
                    outOponente.println(exibirTabuleiro(tabuleiroOponente, false));

                    // Verifica se o jogador venceu
                    if (venceu(tabuleiroOponente)) {
                        out.println("Parabéns! Você venceu o jogo!");
                        outOponente.println("Você perdeu.");
                        break;
                    }
                } catch (NumberFormatException e) {
                    out.println("Entrada inválida. Use números para linha e coluna.");
                }
                turnoJogador1 = !turnoJogador1; // Troca o turno
            }
        } catch (IOException e) {
            System.err.println("Erro no servidor: " + e.getMessage());
        } finally {
            // Fecha tudo certinho no final
            try {
                if (jogador1 != null) jogador1.close();
                if (jogador2 != null) jogador2.close();
                if (servidor != null) servidor.close();
            } catch (IOException e) {
                System.err.println("Erro ao fechar conexões: " + e.getMessage());
            }
        }
    }
}
