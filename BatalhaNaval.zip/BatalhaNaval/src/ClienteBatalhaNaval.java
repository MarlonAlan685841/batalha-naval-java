import java.io.*;
import java.net.*;
import java.util.*;

public class ClienteBatalhaNaval {
    public static void main(String[] args) throws IOException {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Digite o endereço do servidor: ");
        String host = teclado.nextLine();

        Socket socket = new Socket(host, 4444);
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintStream out = new PrintStream(socket.getOutputStream());

        while (true) {
            String resposta = in.readLine();
            if (resposta == null) break;
            System.out.println(resposta);
            if (resposta.contains("formato: linha coluna")) {
                String entrada = teclado.nextLine();
                out.println(entrada);
            } else if (resposta.contains("venceu") || resposta.contains("perdeu")) {
                break;
            }
        }

        socket.close();
        teclado.close();
    }
}

